#include "fencalculatrice.h"
#include <QApplication>

#include <QtWidgets>


int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    Calculatrice fenetre;
    fenetre.show();

    return app.exec();
}
