#ifndef FENCALCULATRICE_H
#define FENCALCULATRICE_H

#include <QMainWindow>

namespace Ui {
class Calculatrice;
}

class Calculatrice : public QMainWindow
{
    Q_OBJECT

public:
    explicit Calculatrice(QWidget *parent = nullptr);
    ~Calculatrice();
private slots:
    void calculerOperation();
private:

    Ui::Calculatrice *ui;
    int op1;
    int op2;
    int rslt;
};

#endif // FENCALCULATRICE_H
