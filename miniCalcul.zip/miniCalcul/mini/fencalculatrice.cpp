#include "fencalculatrice.h"
#include "ui_fencalculatrice.h"

Calculatrice::Calculatrice(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Calculatrice)
{
    ui->setupUi(this);

    connect(ui->boutonEgal, SIGNAL(clicked()), this, SLOT(calculerOperation()));
}

Calculatrice::~Calculatrice()
{
    delete ui;
}
void Calculatrice::calculerOperation()
{
    op1=ui->nombre1->value();
    op2=ui->nombre2->value();
    if (ui->operation->currentText()=="+" )
    ui->resultat->setNum(op1+op2);
    if (ui->operation->currentText()=="-" )
    ui->resultat->setNum(op1-op2);
    if (ui->operation->currentText()=="*" )
    ui->resultat->setNum(op1*op2);
    if (ui->operation->currentText()=="/" )
    ui->resultat->setNum((double)op1/op2);
// if (ui->operation->itemData(ui->operation->currentIndex())
}
