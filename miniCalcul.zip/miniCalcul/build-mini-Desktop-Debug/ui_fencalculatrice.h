/********************************************************************************
** Form generated from reading UI file 'fencalculatrice.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FENCALCULATRICE_H
#define UI_FENCALCULATRICE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Calculatrice
{
public:
    QWidget *centralWidget;
    QSpinBox *nombre1;
    QComboBox *operation;
    QSpinBox *nombre2;
    QPushButton *boutonEgal;
    QLabel *resultat;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *Calculatrice)
    {
        if (Calculatrice->objectName().isEmpty())
            Calculatrice->setObjectName(QStringLiteral("Calculatrice"));
        Calculatrice->resize(400, 300);
        centralWidget = new QWidget(Calculatrice);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        nombre1 = new QSpinBox(centralWidget);
        nombre1->setObjectName(QStringLiteral("nombre1"));
        nombre1->setGeometry(QRect(160, 20, 161, 26));
        operation = new QComboBox(centralWidget);
        operation->setObjectName(QStringLiteral("operation"));
        operation->setGeometry(QRect(80, 50, 41, 20));
        nombre2 = new QSpinBox(centralWidget);
        nombre2->setObjectName(QStringLiteral("nombre2"));
        nombre2->setGeometry(QRect(160, 70, 161, 26));
        boutonEgal = new QPushButton(centralWidget);
        boutonEgal->setObjectName(QStringLiteral("boutonEgal"));
        boutonEgal->setGeometry(QRect(80, 120, 41, 21));
        resultat = new QLabel(centralWidget);
        resultat->setObjectName(QStringLiteral("resultat"));
        resultat->setGeometry(QRect(170, 130, 151, 20));
        Calculatrice->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(Calculatrice);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 400, 22));
        Calculatrice->setMenuBar(menuBar);
        mainToolBar = new QToolBar(Calculatrice);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        Calculatrice->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(Calculatrice);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        Calculatrice->setStatusBar(statusBar);

        retranslateUi(Calculatrice);

        QMetaObject::connectSlotsByName(Calculatrice);
    } // setupUi

    void retranslateUi(QMainWindow *Calculatrice)
    {
        Calculatrice->setWindowTitle(QApplication::translate("Calculatrice", "FenCalculatrice", 0));
        operation->clear();
        operation->insertItems(0, QStringList()
         << QApplication::translate("Calculatrice", "+", 0)
         << QApplication::translate("Calculatrice", "-", 0)
         << QApplication::translate("Calculatrice", "*", 0)
         << QApplication::translate("Calculatrice", "/", 0)
        );
        boutonEgal->setText(QApplication::translate("Calculatrice", "=", 0));
        resultat->setText(QApplication::translate("Calculatrice", "0", 0));
    } // retranslateUi

};

namespace Ui {
    class Calculatrice: public Ui_Calculatrice {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FENCALCULATRICE_H
